# Air Quality Index Prediction
It is winter time and Air Quality Index of Delhi is in every newspaper / news channel. So I decided to create a dataset for New Delhi which can be used to predict its `AQI`.  
The Dataset contains the climate data of New Delhi (Palam) on a day-to-day basis from `January 1, 2010` to `December 31,2018`.     
This is will be an end-to-end project, i.e. from getting data to data wrangling to feature extraction to model creation and then finally deploying it using a `Flask` webapp.        

_*This project is a part of my `WinterOfProjects_2K19`.*_
